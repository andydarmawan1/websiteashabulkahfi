<?php
include('security.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>

<div class="container-fluid">
<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Edit Admin  </h6>
  </div>
  <div class="card-body">
  
<?php
// koneksi dan edit 
$connection = mysqli_connect("localhost", "root", "", "db_tugasakhir");
  if(isset($_POST['edit_btn']))
{
    $id_admin = $_POST['edit_id_admin'];
    $query = "SELECT * FROM admin WHERE id_admin='$id_admin' ";
    $query_run = mysqli_query($connection, $query);

    foreach($query_run as $row)
    {
        ?>
            <form action="action.php" method="POST">

                    <input type="hidden" name="edit_id_admin" value="<?php echo $row['id_admin'] ?>">
                    <!-- modal identitas -->
                    <div class="form-group">
                        <label> Nama Admin </label>
                        <input type="text" name="edit_nama_admin" value="<?php echo $row['nama_admin'] ?>" class="form-control" placeholder="Enter title">
                    </div>
                    <div class="form-group">
                        <label>No. KTP Admin</label>
                        <input type="text" name="edit_no_ktp_admin" value="<?php echo $row['no_ktp_admin'] ?>" class="form-control" placeholder="Enter Subtitle">
                    </div>
                    <div class="form-group">
                        <label>No. HP Admin</label>
                        <input type="text" name="edit_no_hp_admin" value="<?php echo $row['no_hp_admin'] ?>" class="form-control" placeholder="Enter Description">
                    </div>
                    <div class="form-group">
                        <label>Alamat Admin</label>
                        <input type="text" name="edit_alamat_admin" value="<?php echo $row['alamat_admin'] ?>" class="form-control" placeholder="Enter links">
                    </div>
                        
                    <a href="dataadmin.php" class="btn btn-danger" > CANCEL </a>
                    <button type="submit" name="update_dataadmin"class="btn btn-primary"> UPDATE </button>


        
        <?php 
        }
    }
    ?>
    </div>
  </div>
</div>

</div>
<!-- /.container-fluid -->







<?php
include('includes/scripts.php');
include('includes/footer.php');
?>