-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2020 at 05:40 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_tugasakhir`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` int(20) NOT NULL,
  `title` varchar(50) NOT NULL,
  `subtitle` varchar(50) NOT NULL,
  `description` varchar(300) NOT NULL,
  `links` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `title`, `subtitle`, `description`, `links`) VALUES
(1, 'Ashabul Kahfi', 'Pondok Pesantren Ashabul Kahfi', 'Pondok Pesantren Ashabul Kahfi Pondok Pesantren Ashabul Kahfi Pondok Pesantren Ashabul Kahfi Pondok Pesantren Ashabul Kahfi Pondok Pesantren Ashabul Kahfi Pondok Pesantren Ashabul Kahfi Pondok Pesantren Ashabul Kahfi Pondok Pesantren Ashabul Kahfi Pondok Pesantren Ashabul Kahfi Pondok Pesantren Asha', 'www.askaf.com');

-- --------------------------------------------------------

--
-- Table structure for table `absen`
--

CREATE TABLE `absen` (
  `id_absen` int(11) NOT NULL,
  `id_santri` int(11) NOT NULL,
  `alfa` int(11) NOT NULL,
  `sakit` int(11) NOT NULL,
  `izin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_santri` int(11) NOT NULL,
  `id_admin` int(11) NOT NULL,
  `tanggal` datetime NOT NULL,
  `bulan` varchar(20) NOT NULL,
  `nominal` int(20) NOT NULL,
  `terbayar` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `usertype` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`, `usertype`) VALUES
(1, 'Andy Darmawan', 'andydarmawan816@gmail.com', '123', 'admin'),
(2, 'Afifah', 'afifah@gmail.com', '123', 'user'),
(3, 'hadi', 'hadi@gmail.com', '123', 'admin'),
(4, 'Eko Prasetyo', 'Eko@gmail.com', '123', 'user'),
(5, 'Alfin', 'Alfin@gmail.com', '123', 'admin'),
(6, 'Tyka Amelia', 'tyka@gmail.com', '123', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `santri`
--

CREATE TABLE `santri` (
  `id_santri` int(11) NOT NULL,
  `nama_santri` varchar(30) NOT NULL,
  `jeniskelamin` varchar(2) NOT NULL,
  `tempatlahir` varchar(20) NOT NULL,
  `tanggallahir` date NOT NULL,
  `no_ktp` varchar(25) NOT NULL,
  `perguruan_tinggi` varchar(100) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `nama_ayah` varchar(30) NOT NULL,
  `tempat_tgllahir_ayah` varchar(30) NOT NULL,
  `no_ktp_ayah` varchar(25) NOT NULL,
  `alamat_ayah` varchar(200) NOT NULL,
  `no_hp_ayah` varchar(15) NOT NULL,
  `nama_ibu` varchar(30) NOT NULL,
  `tempat_tgllahir_ibu` varchar(30) NOT NULL,
  `no_ktp_ibu` varchar(25) NOT NULL,
  `alamat_ibu` varchar(200) NOT NULL,
  `no_hp_ibu` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `santri`
--

INSERT INTO `santri` (`id_santri`, `nama_santri`, `jeniskelamin`, `tempatlahir`, `tanggallahir`, `no_ktp`, `perguruan_tinggi`, `no_hp`, `alamat`, `nama_ayah`, `tempat_tgllahir_ayah`, `no_ktp_ayah`, `alamat_ayah`, `no_hp_ayah`, `nama_ibu`, `tempat_tgllahir_ibu`, `no_ktp_ibu`, `alamat_ibu`, `no_hp_ibu`) VALUES
(1, 'A. Ilman Fauzi', 'L', '', '2019-10-07', '0', '', '0', '', '', '', '0', '', '0', '', '', '0', '', '0'),
(2, 'MUHAMMAD DZIKRI', 'L', 'Lhoksukon', '2019-08-06', '', 'Politeknik negeri malang jurusan teknik mesin', '085217999914', 'Jl semanggi barat no.1A kota malang.pondok peaantren ashabul kahfi', 'MUHAMMAD YUSUF', '', '', '', '081269662849', '', '', '', '', ''),
(3, 'Mohammad Ikhwan Fauzi', 'L', 'PONOROGO', '2019-08-26', '', 'Polinema Administrasi Niaga', '089506970787', 'Rt 03 Rw 02 Paju Ponorogo', 'Budiono', '', '', 'Rt 03 Rw 02 Paju Ponorogo', '0895366782223', '', '', '', '', ''),
(4, 'Muchammad jamalluddin ', 'L', 'Pasuruan', '2000-09-20', '', 'Universitas Brawijaya/Peternakan', '085851919611', 'Jl.mujair Kauman No.411 Bangil Pasuruan ', 'M.faqih', '', '', '', '081234665211', '', '', '', '', ''),
(5, 'Moh Zainal Alim', 'L', 'Sumenep', '2001-08-10', '', 'Politeknik Negeri Malang dan Administrasi Niaga', '085236514533', 'Dsn. Kalaba\'an Dajah', 'Moh Ruddin', '', '', '', '087866245667', '', '', '', '', ''),
(6, 'TADETIYA YUSMITA PRATAMA', 'L', 'Solo ,karanganyar ', '2001-03-23', '', 'Polinema / jurusan elektro', '081615360061', 'Jl.walet 2 no 1 gka gresik kebomas jawa timur', 'Moh.Yusuf ', '', '', '', '081233594646', '', '', '', '', ''),
(7, 'Fatihul Fikri', 'L', 'Surabaya', '1999-11-10', '', 'UIN Malang. Kimia', '083854436148', 'Jl. Pagesangan IIA no 37', 'Syahrul Munir', '', '', '', '085706642528', '', '', '', '', ''),
(8, 'Febriyandi Anugrah Maulana', 'L', 'Malang', '2019-02-02', '', 'POLINEMA / D-VI JTD', '085733585125', 'DSN Bareng RT 4 RW 2, Sumberejo, Pandaan, Pasuruan', 'Mulyono', '', '', '', '08563946162', '', '', '', '', ''),
(9, 'Lukman Ali Muhyiddin', 'L', 'Tulungagung', '2000-10-14', '', 'Polinema Jurusan Teknik Kimia', '085791649273', 'RT/RW 03/01 Dsn. Tawang Ds. Tugu Kec. Rejotangan Kab. Tulungagung', 'Ali Musthofa', '', '', '', '085745945004', '', '', '', '', ''),
(10, 'Ahmad Zainul RIZKA', 'L', 'Bima,NTB', '2001-12-19', '', 'UMM/informatika', '082228824737', 'Pager kulon,kec Purwosari,kab.pasuruan', 'Mu\'alimin', '', '', '', '085708304802', '', '', '', '', ''),
(11, 'Muhammad taufik hidayat ', 'L', 'Bontang, Kaltim ', '2001-08-26', '', 'Polinema, D3 teknik mesin', '082350513598', 'Bontang, Kalimantan Timur ', 'Edi siswanto', '', '', '', '081253461843', '', '', '', '', ''),
(12, 'Lukman Ali Muhyiddin', 'L', 'Pasuruan', '2001-09-03', '', 'Polinema Elektro prodi D 3 teknik telekomunikasi', '0881026490722', 'Sembung parerejo Purwodadi Pasuruan', 'H Choirul anwar', '', '', '', '081805147652', '', '', '', '', ''),
(13, 'Rifqy Hidayatullah', 'L', 'SUMENEP', '2000-08-24', '', 'UNISMA FKIP (Pendidikan Bahasa & Sastra Indonesia)', '085234512225', 'Dusun Perigi Barat, Ds. Gadu Barat, Kec. Ganding, Kab. Sumenep ', 'Arba\'ie', '', '', '', '082341128693', '', '', '', '', ''),
(14, 'Ahmad zaenal arifin', 'L', 'Malang', '2001-08-23', '', 'Polinema jurusan teknologi informasi', '081358129552', 'Jl.hayam wuruk 1 gondang legi malang', 'Abdul hamid', '', '', '', '085101345199', '', '', '', '', ''),
(15, 'Ali Ar Ridla', 'L', 'Sumenep', '2000-02-11', '', 'Polinema /Teknologi Informasi', '085130336828', 'DSN Guluk-GulukbTengah', 'Surakna', '', '', '', '082302297795', '', '', '', '', ''),
(16, 'M. Iqbal Fatony', 'L', 'Banyuwangi', '2000-05-06', '', 'Polinema D4 Manajemen Pemasaran', '081258135824', 'RT07, RW05, Dusun Krajan, Desa Kebaman, Kec. Srono, Kab. Banyuwangi', 'Ahmad Syaifullah', '', '', '', '085330651993', '', '', '', '', ''),
(17, 'Muhammad Rafli Albar', 'L', 'Pasuruan', '2001-09-03', '', 'Polinema dan Elektro prodi D3 TT', '0881026490722', 'Sembung parerejo Purwodadi Pasuruan', 'H Choirul anwar', '', '', '', '081805147652', '', '', '', '', ''),
(18, 'Moch. Agung Mulyono H.S', 'L', 'Bojonegoro', '2001-03-17', '', 'Polinema, Jurusan Teknik Elektro, Prodi D3 TT', '085235645562', 'Jalan K.H.R Moch. Rosyid, No. 71, RT 02/01, Desa Ngumpak Dalem, Kecamatan Dander, Kab Bojonegoro', 'Supardi', '', '', '', '085231854425', '', '', '', '', ''),
(19, 'Hayatur Rahman', 'L', 'Sumenep', '2000-04-22', '', 'Politeknik Negeri Malang', '085231175692', 'Jln.Pasarean Agung Pandak No.04 Dusun Prigi Barat Desa Gadu Barat Kec Ganding Kab Sumenep Madura', 'Moh.Ramli', '', '', '', '082335067593', '', '', '', '', ''),
(20, 'Royhan Firdaus', 'L', 'Sumenep', '2001-11-13', '', 'Politeknik negeri Malang', '087846123034', 'Panagan Gapura Sumenep', 'Muhdar', '', '', '', '081939436688', '', '', '', '', ''),
(21, 'Mohammad najib alif rahmawan', 'L', 'Lamongan', '2000-12-26', '', 'Polinema manajemen informatika', '081332765222', 'Pangakterjo maduran lamongan', '', '', '', '', '', 'Faidatul khudliyah', '', '', '', '081358453908'),
(22, 'Irsyad Tsani Ramadhan', 'L', 'Pasuruan', '1998-12-25', '', 'Politeknik Negeri Malang/D4 Teknik informatika', '082153125325', 'Perum. Bukit Samboja Indah RT 07 kel. Wonotirto kec. Samboja kab. Kutai Kartanegara', '', '', '', '', '', 'Elly Khuriati', '', '', '', '08123207894'),
(23, 'Zidny Alfian Bachri Erwan S P', 'L', 'Malang', '2001-09-20', '', 'ITN malang dan Jurusan Teknik Mesin S1', '085755809950', 'Jalan ahmad nyani gondanglegi malang', '', '', '', '', '', '', 'Erni Nurul Imamah', '', '', '085791655088'),
(24, 'Izzul Fikri Hidayatullah', 'L', 'Malang', '2001-05-10', '', 'UNISMA Fakultas Keguruan dan ilmu Pendidikan', '082141248921', 'Jl Letjen S. Parman No 07 Rt 10 Rw 01 Kec.Gondanglegi Kab.Malang', '', '', '', '', '', 'Umi azizah', '', '', '', '081333304927'),
(25, 'Sabda Amirul Habib', 'L', 'TUBAN', '2000-05-30', '', 'UMM / T. ELEKTRO', '082140003411', 'Ds. Mentoso Kec. Jenu Kab. Tuban', 'Ramuanto', '', '', '', '081332406730', '', '', '', '', ''),
(26, 'Fahriza Dimas Bayu Andrian', 'L', 'Malang', '2000-08-02', '', 'UIN Maulana Malik Ibrahim Malang - Fisika', '081359844621', 'Jalan Pemancar TVRI RT.01 RW.08 Wonorejo, Lawang, Malang', 'Suriyanto', '', '', '', '085790330847', '', '', '', '', ''),
(27, 'Maulana Yusuf Arraihan ', 'L', 'Brebes', '2001-01-19', '', 'Polinema-Teknik Elektro', '083854433850', 'Perum. Melati Residence A12 Mojosari, Kab. Mojokerto', 'Dedy Arifianto', '', '', '', '081234100053', '', '', '', '', ''),
(28, 'Achmad Alfinda Fadly', 'L', 'Kediri ', '2000-03-24', '3506042403000002', 'Universitas Negeri Malang (Pendidikan  Geografi) ', '085745475714', 'Dsn Ngreco,  Rt/Rt 04/01, Desa Rembang,  kec Ngadiluwih, Kab Kediri', 'Zaenal', 'Kediri, 03 Januari 1973', '3506040301730001', 'Dsn Ngreco,  Rt/Rt 04/01, Desa Rembang,  kec Ngadiluwih, Kab Kediri', '085815964466', 'Nurhayati', 'Kediri,  14 Maret 1979', '3506045403790001', 'Dsn Ngreco,  Rt/Rt 04/01, Desa Rembang,  kec Ngadiluwih, Kab Kediri', '085815964466'),
(29, 'Dhimas afiffudin', 'L', 'Trenggalek', '2000-01-29', '3503062901000001', 'Polinema(D4-sistem kelistrikan)', '082233138733', 'Rt 17 Rw 06 desa Buluagung kec Karangan kab Trenggalek', 'Muyasir(almarhum)', '', '', '', '', 'Katiyah', 'Trenggalek,26 Februari 1970', '3503066602700001', 'Rt 17 Rw 06 desa Buluagung kec Karangan kab Trenggalek', '082233653750'),
(30, 'Ramadian Budi Hardoyo', 'L', 'Kediri', '2000-03-24', '3506042403000002', 'Universitas Negeri Malang (Pendidikan  Geografi) ', '085745475714', 'Dsn Ngreco,  Rt/Rt 04/01, Desa Rembang,  kec Ngadiluwih, Kab Kediri', 'Zaenal', 'Kediri, 03 Januari 1973', '3506040301730001', 'Dsn Ngreco,  Rt/Rt 04/01, Desa Rembang,  kec Ngadiluwih, Kab Kediri', '085815964466', 'Nurhayati', 'Kediri,  14 Maret 1979', '3506045403790001', 'Dsn Ngreco,  Rt/Rt 04/01, Desa Rembang,  kec Ngadiluwih, Kab Kediri', '085815964466'),
(31, 'Ahmad Rofikil Khoiri', 'L', 'Probolinggo', '2000-02-10', '3513111002000001', 'Polinema(Manajemen Informatika)', '085221949589', 'Triwungan Kotaanyar Probolinggo', 'Zubairi', 'Probolinggo,09 Agustus 1970', '3513110908700001', 'Triwungan Kotaanyar Probolinggo', '082302316177', 'Nour Subaihah', 'Probolinggo,05 12 1975', '3513114512750001', 'Triwungan Kotaanyar Probolinggo', '085259010228'),
(32, 'Naufal Hanif Fadhlurrohman Azi', 'L', 'Batu', '2000-02-02', '3507210202000002', 'Polinema (D4 Teknik Mesin Produksi & Perawatan)', '083848414458', 'Triwungan Kotaanyar Probolinggo', 'Sungadi', 'Sragen, 5 Januari 1965', '3507210501650003', 'Perumahan Griya Sejahtera LPK 3 Jl. Joko Tole no.12 kec, wagir, kab. Malang', '08125222926', 'Ika Widianti', 'Batu, 22 Juni 1979', '3507216206790001', 'Perumahan Griya Sejahtera LPK 3 Jl. Joko Tole no.12 kec, wagir, kab. Malang', '081252532224'),
(33, 'Muhammad faqih aulia rahman', 'L', 'Probolinggo', '2000-07-03', '3513120307000003', 'Polinema ( teknik mesin )', '082339637187', 'Sumberanyar paiton probolinggo', 'Jasuli', 'Probolinggo 06 juni 1972', '3513120606720002', 'Sumberanyar paiton probolinggo', '082334509672', 'Nurhani khukmiyati', 'Magelang 7 februari 1977', '3513124702770003', 'Sumberanyar paiton probolinggo', '082330643461'),
(34, 'Ramadian Budi Hardoyo', 'L', 'Siarang - arang', '2000-10-16', '6207021610000002', 'Polinema (teknik mesin )', '081230017671', 'Pakis Durenan Trenggalek', 'Bharma Suhardoyo', 'Surabaya, 16 april 1970', '6207021604700001', 'Pakis Durenan Trenggalek', '082255009775', 'Rohana Patwinarti', 'Trenggalek, 24 oktober 1976', '6207026410760002', 'Pakis Durenan Trenggalek', '081256450357'),
(35, 'Moh. Rijalus Sholihin', 'L', 'Probolinggo', '2000-09-17', '3513101809990002', 'Politeknik Negeri Malang (Teknik Elektro) ', '082337105933', 'Dsn Mungging, RT/RW 008/004, Desa Alas Pandan, Kec. Pakuniran, Kab. Probolinggo', 'Suki Susanto', 'Probolinggo, 20 Maret 1972', '3513102003720002', 'Dsn Mungging, RT/RW 008/004, Desa Alas Pandan, Kec. Pakuniran, Kab. Probolinggo', '082332821906', 'Lusmiati', 'Probolinggo, 6 September 1978', '3513104609780001', 'Pakis Durenan Trenggalek', '081256450357'),
(36, 'Novan Dimas Bayu Andrian', 'L', 'Malang', '2000-08-02', '3507250208000003', 'POLINEMA (Teknik Elektro)', '092337864294', 'Jalan Pemancar TVRI RT 01 RW 08 Krajan Barat, Wonorejo, Lawang - Malang', 'Suriyanto', 'Malang, 3 Juli 1970', '3507250307700009', 'Jalan Pemancar TVRI RT 01 RW 08 Krajan Barat, Wonorejo, Lawang - Malang', '085100358704', 'Arlina', 'Malang, 15 Juli 1976', '3507255507760005', 'Dsn Mungging, RT/RW 008/004, Desa Alas Pandan, Kec. Pakuniran, Kab. Probolinggo', '082332821906'),
(37, 'Najibur Rohman', 'L', 'Jombang', '2000-02-11', '3174091102000003', 'POLINEMA (Teknik Elektro)', '081367246884', 'Jl.Barkah RT/RW 03/05 Ciganjur Jagakarsa Jakarta Selatan', 'Khoirul Waton ', 'Jombang, 06 02 1965', '3174090602650004', 'Jl.Barkah RT/RW 03/05 Ciganjur Jagakarsa Jakarta Selatan ', '08128097630', 'Muawanah', 'Jombang, 20 09 1973', '3174096009730003', 'Jl.Barkah RT/RW 03/05 Ciganjur Jagakarsa Jakarta Selatan ', '081387237458'),
(38, 'Ahmad Zian Paradise', 'L', 'Sumenep', '1999-02-03', '3529090302990003', 'Keuangan', '082330021189', 'Sumenep,Guluk Guluk,Guluk Guluk Timur Kemisan', 'ahmad sahenal', 'Sumenep', '3529091001780005', 'Guluk Guluk Timur', '085336598979', 'Nasilatul Khalisah', 'Sumenep', '3529094201820005', 'Guluk Guluk timur', '082335959531'),
(39, 'Muhammad Hanif Fatchuriza', 'L', 'Kediri', '1999-10-27', '3506252711990002', 'Polinema (D4 Keuangan)', '082234872385', 'Perumahan jenggolo indah R-16 Desa Gogorante Kec. Ngasem Kab. Kediri', 'Imam Kanapi', 'Tulungagung, 09 Juni 1965', '3506250906650001', 'Perumahan jenggolo indah R-16 Desa Gogorante Kec. Ngasem Kab. Kediri', '081234307513', 'Anik Purwati', 'Nganjuk, 13 Agustus 1972', '3506255308720001', 'Perumahan jenggolo indah R-16 desa Gogorante kec. Ngasem Kab. Kediri', '081335490351'),
(40, 'ACH. Turmudzi Ramadhani', 'L', 'sumenep', '2000-01-07', '3529070701001155', 'polinema Teknik mesin', '083117908295', 'meddelan lenteng sumenep', 'SUBARDI', 'sumenep 19-12-1966', '3529071912660001', 'meddelan lenteng sumenep', '082338868740', 'MARDIYA', 'sumenep 03-11-1976 ', '3529074311760005', 'meddelan lenteng sumenep', '085231146450'),
(41, 'Nur Hamid Fuadi', 'L', 'Nganjuk', '2000-07-07', '3518070706000003', 'UM (Biologi)', '081515102767', 'Sukorejo, Klurahan, Ngronggot, Nganjuk', 'Alm. Muh Kusnan', 'Kediri, 13 Oktober 1954', '', 'Sukorejo, Klurahan, Ngronggot, Nganjuk', '', 'Ulfatul Hasanah', 'Nganjuk, 29 Agustus 1965', '', 'Sukorejo, Klurahan, Ngronggot, Nganjuk', '085755490908'),
(42, 'M. Yuki Miftakhurrizqi', 'L', 'Sidoarjo', '2000-03-02', '3515140203000003', 'Polinema (D3 Manajemen Informatika)', '085606164346', 'Plumbungan RT.11 RW 04 Sukodono Sidoarjo', 'Abd. Ghofur', 'Sidoarjo, 02 Mei 1971', '3515140205710001', 'Plumbungan RT.11 RW 04 Sukodono Sidoarjo', '082220314531', 'Churiyah Milqiyatinu', 'Sidoarjo, 28 Maret 1973', '3515146803730001', 'Plumbungan RT.11 RW 04 Sukodono Sidoarjo', '081235054133'),
(43, 'Achmad dzulfikri almufti asyha', 'L', 'Kediri', '2000-02-23', '3518132302000004', 'UM (pend.biologi)', '082244295763', 'Jl.letjend suprapto 1a ds. Ploso kec. Nganjuk kab.nganjuk', 'Imam mahmud', 'Nganjuk 26 februari 1978', '3518132802730004', 'Jl.letjend suprapto 1a ds. Ploso kec. Nganjuk kab.nganjuk', '085233901873', 'Luluk dewi masruroh', 'Kediri 7 agustus 1981', '3518134708760001', 'Jl.letjend suprapto 1a ds. Ploso kec. Nganjuk kab.nganjuk', '085335061928'),
(44, 'Tito Rizky Budi Pratama', 'L', 'Kediri', '1999-10-30', '3506063010990002', 'Universitas Negri Malang (Ilmu Keolahragaan)', '085736850028', 'Dsn.Ngelowan Rt.15/Rw.04 Ds.Duwet, Kec.Wates, Kab.Kediri, Jawa Timur', 'Budiono', 'Kediri, 19 Februari 1969', '3506061902690001', 'Dsn.Ngelowan Rt.15/Rw.04 Ds.Duwet, Kec.Wates, Kab.Kediri, Jawa Timur', '081234065758', 'Hariyanti', 'Kediri, 25 Agustus 1979', '3506066508790002', 'Dsn.Ngelowan Rt.15/Rw.04 Ds.Duwet, Kec.Wates, Kab.Kediri, Jawa Timur', '085730412578'),
(45, 'Muhammad Hafizh Irsan Santoso', 'L', 'Mojokerto', '2000-05-06', '', 'Polinema ( Teknik Sipil)', '089676782380', 'Villa Adonia D.8 BSP Sooko', 'Pudji Santoao', 'Surabaya 18 juli 1967', '3576011807670001', 'Villa Adonia D.8 BSP Sooko', '081235429872', 'Erawati Yuana', 'Mojokerto 30 januari 1969', '3576017001690001', 'Villa Adonia D.8 BSP Sooko', '081331866047'),
(46, 'Ahmad Zainurridha', 'L', 'Sumenep', '2000-01-15', '3529071501000002', 'Polinema D4 manajemen pemasaran', '081357953839', 'Moncek Barat Lenteng Sumenep', 'Abul Chair', 'Sumenep 21 mei 1978', '3529072105780004', 'Moncek barat lenteng sumenep', '082333821517', 'Nur Hayati', 'Sumenep 20 nopember 1979', '3529076011790005', 'Moncek barat lenteng sumenep', '082333821517'),
(47, 'Akmal fahmi', 'L', 'Sampang', '2000-07-13', '', 'UM (GEOGRAFI)', '081359028663', 'Jl sumber omben sampang  madura', 'Supandi', 'Pamekasan 07 juli 1956', '', 'Jl sersan misrul pamekasa madura', '085233041640', 'Hanifah', 'Sampang 17 mei 1960', '', 'Jl sumber omben sampang madura', '0878557850106'),
(48, 'Bangkit Nasrul Khaq', 'L', 'Kediri', '2000-08-25', '3506022508990001', 'Polinema teknik sipil', '081615486412', 'RT 2/RW 2 dusun pelem desa Medan kecamatan mojo kabupaten Kediri ', 'Jaelani', 'Kediri, 09 Juni 19719', '3506020906710001', 'Pelem Maesan mojo kediri', '085851366065', 'Nurhidayati', 'Kediri, 17 Agustus 1976', '3506025708770005', 'Pelem Maesan mojo kediri', '085235890875'),
(49, 'Achmad nurdiansyah', 'L', 'Gresik', '2000-07-24', '3525102407990003', 'Polinema (managemen pemasaran) ', '085785980062', 'Jl satelit X manyar-manyarejo', 'Ach afif', 'Gresik,  02-04-1967', '3525100204670004', 'Jl satelit X manyar-manyarejo', '085859284961', 'Yuanik wijaya', 'Tuban,  16-07-1968', '352510567680003', 'Jl satelit X manyar-manyarejo', '085806983405'),
(50, 'Abdullah faqih', 'L', 'Probolinggo', '2000-04-04', '3513120404000005', 'Unisma jurusan teknik mesin', '082233107457', 'Dusun curah rt 3 rw 5 petunjungan paiton probolinggo', 'Abdullah', 'Probolinggo, 08-02-1971', '3513120802710001', 'Dusun curah rt 3 rw 5 petunjungan paiton probolinggo', '085258718369', 'Yuliati', 'Probolinggo, 02-12-1973', '3513124212730002', 'Dusun curah rt 3 rw 5 petunjungan paiton probolinggo', '082233107457'),
(51, 'Afifah', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(52, 'Aliv Srianissya B', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(53, 'Amyrah P. Hartanto', 'P', 'Bekasi', '2002-01-09', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(54, 'Anila Wirrantika', 'P', 'Purbalingga', '2001-04-11', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(55, 'Anisah', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(56, 'Annisah/Ninis', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(57, 'Arsellina Khoirunnisa Caroline', 'P', 'Sumenep', '2001-06-06', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(58, 'Astika Pujiarti', 'P', 'Nganjuk', '2001-07-12', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(59, 'Aulia Umi N', 'P', 'Malang', '2001-12-18', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(60, 'Ayu Miladiyana Aslamiyah', 'P', 'Banyuwangi', '1999-03-03', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(61, 'Cahyani Septyana', 'P', 'Probolinggo', '1999-09-24', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(62, 'Dahlia Adies Sakina', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(63, 'Danish Nurul Fadilah', 'P', 'Malang', '2001-08-01', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(64, 'Diana Assholehah', 'P', 'Sampang', '2000-02-18', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(65, 'Dinatul Islamiyah', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(66, 'Durrotul Ainiyah', 'P', 'Jombang', '1998-03-28', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(67, 'Eka Nurhayati', 'P', 'Nganjuk', '2000-10-08', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(68, 'Elok Amalia', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(69, 'Erika Amalia ', 'P', 'Probolinggo', '2001-08-01', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(70, 'Evelyn Zhahlita F', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(71, 'Faiqotul Himmah', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(72, 'Ica Amarta', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(73, 'Ihshania Yulita Natory', 'P', 'Malang', '1997-10-08', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(74, 'Ikrimatuz Zulaykha', 'P', 'Malang', '2001-07-07', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(75, 'Ilmiana Nurur Rohma', 'P', 'Bojonegoro', '2000-04-01', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(76, 'Indah Suci Fatmah Sari', 'P', 'Probolinggo', '2000-12-12', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(77, 'Intan Fadilla', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(78, 'Ira Zulfia', 'P', 'Malang', '2000-06-16', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(79, 'Isrul An Nuriah', 'P', 'Nganjuk', '2000-09-25', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(80, 'Jamilatul Badriyah', 'P', 'Probolinggo', '1999-11-04', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(81, 'Kartika Sari', 'P', 'Pasuruan', '1999-11-27', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(82, 'Kumala Alda Z', 'P', 'Nganjuk', '2000-01-01', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(83, 'Laila Nuril Fadilah', 'P', 'Blora', '2001-04-01', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(84, 'Laila Rizqi Rhomadiani', 'P', 'Lamongan', '2001-12-16', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(85, 'Lila Mufidatul Khasanah', 'P', 'Malang', '1999-04-03', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(86, 'Lutfiatun Hasanah', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(87, 'Makkiyah', 'P', 'Sumenep', '2001-05-11', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(88, 'Nabilah Roisul A', 'P', 'probolinggo', '1999-11-08', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(89, 'Puji Astutik', 'P', 'Pasuruan', '2000-11-06', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(90, 'Riris Silvia Zahri', 'P', 'Malang', '2001-03-12', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(91, 'Rizka Hayyu Mustofa', 'P', 'Pasuruan', '2001-07-29', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(92, 'Rizki Novitaria Rahmawati', 'P', 'Kediri', '1999-11-13', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(93, 'Runiatus Sa`adah', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(94, 'Salamatul Hifdiyah', 'P', 'Pasuruan', '2001-06-07', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(95, 'Sayyidah Khaizatul U', 'P', 'Lumajang', '1997-11-04', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(96, 'Shinta Adinda', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(97, 'Shofia Anjarsari', 'P', 'Tulungagung', '1999-09-06', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(98, 'Silmi Kumala Dewi', 'P', 'Semarang', '2000-06-06', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(99, 'Siti Alhikmatul Hidayah', 'P', 'Pasuruan', '1998-10-14', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(100, 'Siti Hajar', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(101, 'Siti Novia Sari', 'P', 'Nganjuk', '2000-10-17', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(102, 'Ulaa Masrurotus Saniyah', 'P', 'Malang', '2000-10-14', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(103, 'Wilujeng F.', 'P', 'Probolinggo', '2000-01-15', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(104, 'Zahra Habibah Maharani', 'P', 'Malang', '1999-10-29', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(105, 'Zumrotul Fahmia', 'P', 'Malang', '1998-11-17', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(106, 'Salsabila', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(107, 'Ulfa Rida', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(108, 'Ifa Datus Salamah', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(109, 'Nahdiyah Lifah', 'P', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `absen`
--
ALTER TABLE `absen`
  ADD PRIMARY KEY (`id_absen`),
  ADD KEY `id_santri` (`id_santri`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD KEY `id_santri` (`id_santri`),
  ADD KEY `id_admin` (`id_admin`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `santri`
--
ALTER TABLE `santri`
  ADD PRIMARY KEY (`id_santri`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `absen`
--
ALTER TABLE `absen`
  MODIFY `id_absen` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `santri`
--
ALTER TABLE `santri`
  MODIFY `id_santri` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `absen`
--
ALTER TABLE `absen`
  ADD CONSTRAINT `absen_ibfk_1` FOREIGN KEY (`id_santri`) REFERENCES `santri` (`id_santri`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
