<?php
include('security.php');
// include('includes/header.php'); 
// include('includes/navbar.php'); 

$connection = mysqli_connect("localhost", "root", "", "db_tugasakhir");
$id=$_GET['id'];
    
    $delete="DELETE FROM `santri` WHERE id_santri='$id'";
    $query_run = mysqli_query($connection, $delete);
    if($query_run){
    	 echo "<script>window.alert('Delete data berhasil')</script>";
		 echo "<script>window.location=('datasantri.php')</script>";
    }else{
    	echo "<script>window.alert('Delete data tidak berhasil')</script>";
		 echo "<script>window.location=('datasantri.php')</script>";
    }

?>

