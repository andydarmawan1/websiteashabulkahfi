<?php
// session_start();
include('security.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Santri Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="action.php" method="POST">

        <div class="modal-body">

          <div class="form-group">
            <label>Nama Santri</label>
            <input type="text" name="nama_santri" class="form-control" placeholder="Nama Santri">
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" name="emailsantri" class="form-control" placeholder="Email">
          </div>            
          <div class="form-group">
            <label>Jenis Kelamin</label>
            <div class="col-sm-10">
              <input type="radio" value="L" name="jeniskelamin">Laki-Laki<br>
              <input type="radio" value="P" name="jeniskelamin">perempuan
            </div>
          </div>
          <div class="form-group">
            <label>Tempat Lahir</label>
            <input type="text" name="tempatlahir" class="form-control" placeholder="Tempat Lahir">
          </div>
          <div class="form-group">
            <label>Tanggal lahir</label>
            <input type="date" name="tanggallahir" class="form-control" placeholder="Tanggal lahir">
          </div>
          <div class="form-group">
            <label>No. KTP </label>
            <input type="text" name="no_ktp" class="form-control" placeholder="No. KTP">
          </div>
          <div class="form-group">
            <label>Perguruan Tinggi</label>
            <input type="text" name="perguruan_tinggi" class="form-control" placeholder="Perguruan Tinggi">
          </div>
          <div class="form-group">
            <label>No. Handphone</label>
            <input type="text" name="no_hp" class="form-control" placeholder="No. Handphone">
          </div>
          <div class="form-group">
            <label>Alamat</label>
            <textarea type="text" name="alamat" class="form-control" placeholder="Alamat"> </textarea>       
          </div>
          <div class="form-group">
            <label>Nama Ayah</label>
            <input type="text" name="nama_ayah" class="form-control" placeholder="Nama Ayah">
          </div>
          <div class="form-group">
            <label>Tempat, Tanggal Lahir Ayah</label>
            <input type="text" name="tempat_tgllahir_ayah" class="form-control" placeholder="Tempat, yyyy-mm-dd">
          </div>
          <div class="form-group">
            <label>No. KTP Ayah</label>
            <input type="text" name="no_ktp_ayah" class="form-control" placeholder="No. KTP Ayah"> 
          </div>
          <div class="form-group">
            <label>Alamat Ayah</label>
            <textarea type="text" name="alamat_ayah" class="form-control" placeholder="Alamat Ayah"> </textarea>       
          </div>
          <div class="form-group">
            <label>No. HP Ayah</label>
            <input type="text" name="no_hp_ayah" class="form-control" placeholder="No. HP Ayah"> 
          </div>
          <div class="form-group">
            <label>Nama Ibu</label>
            <input type="text" name="nama_ibu" class="form-control" placeholder="Nama Ibu">
          </div>
          <div class="form-group">
            <label>Tempat Tanggal Lahir Ibu</label>
            <input type="text" name="tempat_tgllahir_ibu" class="form-control" placeholder="Tempat, yyyy-mm-dd">
          </div>
          <div class="form-group">
            <label>No. KTP Ibu</label>
            <input type="text" name="no_ktp_ibu" class="form-control" placeholder="No. KTP Ibu"> 
          </div>
          <div class="form-group">
            <label>Alamat Ibu</label>
            <textarea type="text" name="alamat_ibu" class="form-control" placeholder="Alamat Ibu"> </textarea>       
          </div>
          <div class="form-group">
            <label>No. HP Ibu</label>
            <input type="text" name="no_hp_ibu" class="form-control" placeholder="No. HP Ibu"> 
          </div>            
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" name="datasantri_save" class="btn btn-primary">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>



<div class="container-fluid">
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Daftar Santri Baru 
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
          Tambah
        </button>
      </h6>
    </div>

    <div class="card-body">
      <?php
      if(isset($_SESSION['success']) && $_SESSION['success'] !='')
      {
        echo '<h2 class="bg-primary text-white"> '.$_SESSION['success'].' </h2>';
        unset($_SESSION['success']);
      }

      if(isset($_SESSION['status']) && $_SESSION['status'] !='')
      {
        echo '<h2 class="bg-danger text-white"> '.$_SESSION['status'].' </h2>';
        unset($_SESSION['status']);
      }
      ?>
      <div class="table-responsive">

        <?php
        $connection = mysqli_connect("localhost","root","","db_tugasakhir");
        $query = "SELECT * FROM santri";
        $query_run = mysqli_query($connection, $query);
        ?>

        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th> ID </th>
              <th> Nama Santri </th>
              <th> Jenis Kelamin </th>
              <th> Tempat Lahir</th>
              <th> Tanggal Lahir</th>
              <th>EDIT </th>
              <th>DELETE </th>
            </tr>
          </thead>
          <tbody>
            <?php
            if(mysqli_num_rows($query_run) > 0)
            {
              while($row = mysqli_fetch_assoc($query_run))
              {
               ?> 
               <tr>
                <td><?php echo $row['id_santri']; ?></td>
                <td><?php echo $row['nama_santri']; ?></td>
                <td><?php echo $row['jeniskelamin']; ?></td>
                <td><?php echo $row['tempatlahir']; ?></td>
                <td><?php echo $row['tanggallahir']; ?></td>
                <td>
                  <form action="edit_datasantri.php?id=<?php echo $row['id_santri']; ?>" method="post">
                    <input type="hidden" name="edit_id_santri" value="<?php echo $row['id_santri']; ?>">
                    <button type="submit" name="edit_btn" class="btn btn-success"> EDIT </button>
                  </form>            
                </td>
                <td>
                  <a href="delete_datasantri.php?id=<?php echo $row['id_santri']; ?>" onclick="return confirm('Apakah anda ingin menghapus data ini ?')" class="btn btn-danger">Hapus</a>
                </td>
              </tr>
              <?php
            }
          }  
          else {
            echo "No Record Found";
          }
          ?> 
          
        </tbody>
      </table>

    </div>
  </div>
</div>

</div>
<!-- <div class="container-fluid"> -->

  <?php
  include('includes/scripts.php');
  include('includes/footer.php');
  ?>