<?php
include('security.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>

<div class="container-fluid">
<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Edit Admin Profile </h6>
  </div>
  <div class="card-body">
  
<?php
// koneksi dan edit 
$connection = mysqli_connect("localhost", "root", "", "db_tugasakhir");
  if(isset($_POST['edit_btn']))
{
    $id_register = $_POST['edit_id'];
    $query = "SELECT * FROM register WHERE id_register='$id_register' ";
    $query_run = mysqli_query($connection, $query);

    foreach($query_run as $row)
    {
        ?>
            <form action="action.php" method="POST">

                    <input type="hidden" name="edit_id" value="<?php echo $row['id_register'] ?>">
                    <!-- modal identitas -->
                    <div class="form-group">
                        <label> Username </label>
                        <input type="text" name="edit_username" value="<?php echo $row['username'] ?>" class="form-control" placeholder="Enter Username">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="edit_email" value="<?php echo $row['email'] ?>" class="form-control" placeholder="Enter Email">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="edit_password" value="<?php echo $row['password'] ?>" class="form-control" placeholder="Enter Password">
                    </div>
                    <div class="form-group">
                        <label>USERTYPE</label>
                        <!-- <select name="update_usertype" class="form-control">
                          <option value="admin"> Admin </option>
                          <option value="user"> User </option>
                        </select> -->
                        <select name="update_usertype" class="form-control" required="">
                              <?php
                              if ($row['update_usertype'] == "admin"){
                                echo "<option value='admin' selected>Admin</option>    
                                <option value='user'>User</option>";
                              } else if ($row['update_usertype'] == "user"){
                                echo "<option value='admin'>Admin</option>    
                                <option value='user' selected>User</option>";
                              }
                              ?>
                            </select> 
                    </div>
                        
                    <a href="dataregister.php" class="btn btn-danger" > CANCEL </a>
                    <button type="submit" name="updatebtn"class="btn btn-primary"> UPDATE </button>


        
        <?php 
        }
    }
    ?>
    </div>
  </div>
</div>

</div>
<!-- /.container-fluid -->







<?php
include('includes/scripts.php');
include('includes/footer.php');
?>