<?php
include('security.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>

<div class="container-fluid">
<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Edit Data Santri  </h6>
  </div>
  <div class="card-body">
  
<?php
// koneksi dan edit 
$connection = mysqli_connect("localhost", "root", "", "db_tugasakhir");
  if(isset($_POST['edit_btn']))
{
    $id_santri = $_POST['edit_id_santri'];
    $query = "SELECT * FROM santri WHERE id_santri='$id_santri' ";
    $query_run = mysqli_query($connection, $query);

    foreach($query_run as $row)
    {
        ?>
            <form action="action.php" method="POST">

                    <input type="hidden" name="edit_id_santri" value="<?php echo $row['id_santri'] ?>">
                    <!-- modal identitas -->
                    <div class="form-group">
                        <label> Nama Santri </label>
                        <input type="text" name="edit_nama_santri" value="<?php echo $row['nama_santri'] ?>" class="form-control" placeholder="Nama Santri">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="edit_emailsantri" value="<?php echo $row['emailsantri'] ?>" class="form-control" placeholder="Email">
                    </div>
                    <div class="form-group">
                        <label>Jenis Kelamin</label><br>
                            <input  type="radio" name="edit_jeniskelamin" value="L" <?php if ($row['jeniskelamin']=='L') { echo 'checked';}?>> Laki-laki
                            <input  type="radio" name="edit_jeniskelamin" value="P" <?php if ($row['jeniskelamin']=='P') { echo 'checked';}?>> Perempuan
                    </div>
                    <div class="form-group">
                        <label>Tempat Lahir</label>
                        <input type="text" name="edit_tempatlahir" value="<?php echo $row['tempatlahir'] ?>" class="form-control" placeholder="Tempat Lahir">
                    </div>
                    <div class="form-group">
                        <label>Tanggal Lahir</label>
                        <input type="date" name="edit_tanggallahir" value="<?php echo $row['tanggallahir'] ?>" class="form-control" placeholder="Tanggal Lahir">
                    </div>
                    <div class="form-group">
                        <label>No. KTP</label>
                        <input type="text" name="edit_no_ktp" value="<?php echo $row['no_ktp'] ?>" class="form-control" placeholder="No. KTP">
                    </div>
                    <div class="form-group">
                        <label>Perguruan Tinggi</label>
                        <input type="text" name="edit_perguruan_tinggi" value="<?php echo $row['perguruan_tinggi'] ?>" class="form-control" placeholder="Perguruan Tinggi">
                    </div>
                    <div class="form-group">
                        <label>No. HP</label>
                        <input type="text" name="edit_no_hp" value="<?php echo $row['no_hp'] ?>" class="form-control" placeholder="No. HP">
                    </div>
                    <div class="form-group">
                        <label>Alamat</label>
                        <input type="text" name="edit_alamat" value="<?php echo $row['alamat'] ?>" class="form-control" placeholder="Alamat">
                    </div>
                    <div class="form-group">
                        <label>Nama Ayah</label>
                        <input type="text" name="edit_nama_ayah" value="<?php echo $row['nama_ayah'] ?>" class="form-control" placeholder="Nama Ayah">
                    </div>
                    <div class="form-group">
                        <label>Tempat, Tanggal lahir Ayah</label>
                        <input type="text" name="edit_tempat_tgllahir_ayah" value="<?php echo $row['tempat_tgllahir_ayah'] ?>" class="form-control" placeholder="Tempat, Tanggal lahir Ayah">
                    </div>
                    <div class="form-group">
                        <label>No. KTP Ayah</label>
                        <input type="text" name="edit_no_ktp_ayah" value="<?php echo $row['no_ktp_ayah'] ?>" class="form-control" placeholder="No. KTP Ayah">
                    </div>          
                    <div class="form-group">
                        <label>Alamat Ayah</label>
                        <input type="text" name="edit_alamat_ayah" value="<?php echo $row['alamat_ayah'] ?>" class="form-control" placeholder="Alamat Ayah">
                    </div>
                    <div class="form-group">
                        <label>No. HP Ayah</label>
                        <input type="text" name="edit_no_hp_ayah" value="<?php echo $row['no_hp_ayah'] ?>" class="form-control" placeholder="No. HP Ayah">
                    </div>
                    <div class="form-group">
                        <label>Nama Ibu</label>
                        <input type="text" name="edit_nama_ibu" value="<?php echo $row['nama_ibu'] ?>" class="form-control" placeholder="Nama Ibu">
                    </div>
                    <div class="form-group">
                        <label>Tempat, Tanggal lahir Ibu</label>
                        <input type="text" name="edit_tempat_tgllahir_ibu" value="<?php echo $row['tempat_tgllahir_ibu'] ?>" class="form-control" placeholder="Tempat, Tanggal lahir Ibu">
                    </div>
                    <div class="form-group">
                        <label>No. KTP Ibu</label>
                        <input type="text" name="edit_no_ktp_ibu" value="<?php echo $row['no_ktp_ibu'] ?>" class="form-control" placeholder="No. KTP Ibu">
                    </div>          
                    <div class="form-group">
                        <label>Alamat Ibu</label>
                        <input type="text" name="edit_alamat_ibu" value="<?php echo $row['alamat_ibu'] ?>" class="form-control" placeholder="Alamat Ibu">
                    </div>
                    <div class="form-group">
                        <label>No. HP Ibu</label>
                        <input type="text" name="edit_no_hp_ibu" value="<?php echo $row['no_hp_ibu'] ?>" class="form-control" placeholder="No. HP Ibu">
                    </div>                                                                                            
                    <a href="datasantri.php" class="btn btn-danger" > CANCEL </a>
                    <button type="submit" name="update_datasantri"class="btn btn-primary"> UPDATE </button>
        <?php 
        }
    }
    ?>
    </div>
  </div>
</div>

</div>
<!-- /.container-fluid -->







<?php
include('includes/scripts.php');
include('includes/footer.php');
?>