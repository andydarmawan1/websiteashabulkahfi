
<?php
// session_start();
include('security.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Admin Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="action.php" method="POST">

        <div class="modal-body">

            <div class="form-group">
                <label> Nama Admin </label>
                <input type="text" name="nama_admin" class="form-control" placeholder="Nama Admin">
            </div>
            <div class="form-group">
                <label>No. KTP Admin</label>
                <input type="text" name="no_ktp_admin" class="form-control" placeholder="No. KTP Admin">
            </div>
            <div class="form-group">
                <label>No. HP Admin</label>
                <input type="text" name="no_hp_admin" class="form-control" placeholder="No. HP Admin">
            </div>
            <div class="form-group">
                <label>Alamat Admin</label>
                <textarea type="text" name="alamat_admin" class="form-control" placeholder="Alamat Lengkap"> </textarea>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="dataadmin_save" class="btn btn-primary">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>



<div class="container-fluid">
<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Data Admin
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
              Tambah
            </button>
    </h6>
  </div>

  <div class="card-body">
    <?php
    if(isset($_SESSION['success']) && $_SESSION['success'] !='')
    {
      echo '<h2 class="bg-primary text-white"> '.$_SESSION['success'].' </h2>';
      unset($_SESSION['success']);
    }

    if(isset($_SESSION['status']) && $_SESSION['status'] !='')
    {
      echo '<h2 class="bg-danger text-white"> '.$_SESSION['status'].' </h2>';
      unset($_SESSION['status']);
    }
    ?>
    <div class="table-responsive">

    <?php
        $connection = mysqli_connect("localhost","root","","db_tugasakhir");
        $query = "SELECT * FROM admin";
        $query_run = mysqli_query($connection, $query);
    ?>

      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> ID </th>
            <th> Nama Admin </th>
            <th> No. KTP Admin </th>
            <th> No. HP Admin </th>
            <th> Alamat Admin </th>
            <th>EDIT </th>
            <th>DELETE </th>
          </tr>
        </thead>
        <tbody>
        <?php
        if(mysqli_num_rows($query_run) > 0)
        {
          while($row = mysqli_fetch_assoc($query_run))
          {
             ?> 
          <tr>
              <td><?php echo $row['id_admin']; ?></td>
              <td><?php echo $row['nama_admin']; ?></td>
              <td><?php echo $row['no_ktp_admin']; ?></td>
              <td><?php echo $row['no_hp_admin']; ?></td>
              <td><?php echo $row['alamat_admin']; ?></td>
              <td>
                   <form action="edit_dataadmin.php?id=<?php echo $row['id_admin']; ?>" method="post">
                    <input type="hidden" name="edit_id_admin" value="<?php echo $row['id_admin']; ?>">
                    <button type="submit" name="edit_btn" class="btn btn-success"> EDIT </button>
                  </form>            
                </td>
                <td>
                  <a href="delete_dataadmin.php?id=<?php echo $row['id_admin']; ?>" onclick="return confirm('Apakah anda ingin menghapus data ini ?')" class="btn btn-danger">Hapus</a>
                </td>
          </tr>
          <?php
          }
        }  
        else {
          echo "No Record Found";
        }
        ?> 
     
        </tbody>
      </table>

    </div>
  </div>
</div>

</div>
<!-- <div class="container-fluid"> -->

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>