<?php
// session_start();
include('security.php');
include('includes/header.php'); 
include('includes/navbar.php'); 



?>
        <?php
        $connection = mysqli_connect("localhost","root","","db_tugasakhir");
        $query = "SELECT * FROM santri";
        $query_run = mysqli_query($connection, $query);
        ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Kelola Data Karyawan</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Kelola Data Karyawan</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            
            <br/>
                <a href="Input_datasantri.php" class="btn btn-warning">Tambah Data Santri</a><br/>
                <br/>
                  
                <table class="table table-bordered">
                  <thead> 
                    <tr bgcolor="#C0C0C0">
                      <td align="center"><b>ID</b></td>
                      <td align="center"><b>Nama Santri</b></td>
                      <td align="center"><b>Jenis Kelamin</b></td>
                      <td align="center"><b>Tanggal Lahir</b></td>
                      <td align="center"><b>Tempat Lahir</b></td>
                      <td align="center" colspan="3"><b>ACTION</b></td>
                    </tr>
                  </thead>
                  <tbody>
            <?php
            if(mysqli_num_rows($query_run) > 0)
            {
              while($row = mysqli_fetch_assoc($query_run))
              {
               ?>
                      <tr align="center">
                        <th><?= $row["id_santri"]; ?></th>
                        <th><?= $row["nama_santri"]; ?></th>
                        <th><?= $row["jeniskelamin"]; ?></th>
                        <th><?= $row["tempatlahir"]; ?></th>
                        <th><?= $row["tanggallahir"]; ?></th>
                        <!-- ================================BUTTON====================================== -->
                        <td align="center"><a class="btn btn-info" href="Edit_datasantrinew.php?id=<?php echo $row['id_santri'];?>">Edit <br></td><!-- untuk ke tampilan edit -->
                          <td align="center"><a class="btn btn-warning" href="Printt.php?id=<?php echo $row['id_santri'];?>">Print</a></td>
                          <td align="center"><a class="btn btn-dark" href="DeleteKaryawan.php?id=<?php echo $row['id_santri'];?>">Delete</a></a></td> <!-- untuk menghapus data -->
                        </tr>              <?php
            }
          }  
          else {
            echo "No Record Found";
          }
          ?> 
                    </table>

               
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->



  <?php
  include('includes/scripts.php');
  include('includes/footer.php');
  ?>