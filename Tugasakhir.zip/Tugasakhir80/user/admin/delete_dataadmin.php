<?php
include('security.php');
// include('includes/header.php'); 
// include('includes/navbar.php'); 

$connection = mysqli_connect("localhost", "root", "", "db_tugasakhir");
$id=$_GET['id'];
    
    $delete="DELETE FROM `admin` WHERE id_admin='$id'";
    $query_run = mysqli_query($connection, $delete);
    if($query_run){
    	 echo "<script>window.alert('Delete data berhasil')</script>";
		 echo "<script>window.location=('dataadmin.php')</script>";
    }else{
    	echo "<script>window.alert('Delete data tidak berhasil')</script>";
		 echo "<script>window.location=('dataadmin.php')</script>";
    }

?>

