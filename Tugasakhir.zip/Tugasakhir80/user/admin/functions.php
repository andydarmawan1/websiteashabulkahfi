<?php
$conn=mysqli_connect("localhost","root","","db_tugasakhir");

if(!$conn){
    die('Kondisi Error : '.mysqli_connect_errno().' - '.mysqli_connect_error());
}
// $result=mysqli_query($conn, "SELECT * FROM tb_karyawan" );

function query($query_kedua){
    global $conn;
    $result=mysqli_query($conn,$query_kedua);
    $rows = [];
    while($row = mysqli_fetch_assoc($result)){
        $rows[]=$row;
    }

    return $rows;
}

/////////////////////////////////////////////////////////////////
//Input Karyawan
function input_santri($data){
    global $conn;

    $nama_santri            = htmlspecialchars($_POST['nama_santri']);  
    $email                  = htmlspecialchars($_POST['email']);
    $jeniskelamin           = htmlspecialchars($_POST['jeniskelamin']);
    $tempatlahir            = htmlspecialchars($_POST['tempatlahir ']);
    $tanggallahir           = htmlspecialchars($_POST['tanggallahir']);
    $no_ktp                 = htmlspecialchars($_POST['no_ktp']);
    $perguruan_tinggi       = htmlspecialchars($_POST['perguruan_tinggi']);
    $no_hp                  = htmlspecialchars($_POST['no_hp']);
    $alamat                 = htmlspecialchars($_POST['alamat']);
    $nama_ayah              = htmlspecialchars($_POST['nama_ayah']);
    $tempat_tgllahir_ayah   = htmlspecialchars($_POST['tempat_tgllahir_ayah']);
    $no_ktp_ayah            = htmlspecialchars($_POST['no_ktp_ayah']);
    $alamat_ayah            = htmlspecialchars($_POST['alamat_ayah']);
    $no_hp_ayah             = htmlspecialchars($_POST['no_hp_ayah']);
    $nama_ibu               = htmlspecialchars($_POST['nama_ibu']);
    $tempat_tgllahir_ibu    = htmlspecialchars($_POST['tempat_tgllahir_ibu']);
    $no_ktp_ibu             = htmlspecialchars($_POST['no_ktp_ibu']);
    $alamat_ibu             = htmlspecialchars($_POST['alamat_ibu']);
    $no_hp_ibu              = htmlspecialchars($_POST['no_hp_ibu']);


    $query          = "INSERT INTO datasantri values ('','$email' '$nama_santri', '$jeniskelamin', '$tempatlahir', '$tanggallahir', '$no_ktp', '$perguruan_tinggi', '$no_hp', '$alamat', '$nama_ayah', '$tempat_tgllahir_ayah', '$no_ktp_ayah', '$alamat_ayah', '$no_hp_ayah', '$nama_ibu', '$tempat_tgllahir_ibu', '$no_ktp_ibu', '$alamat_ibu', '$no_hp_ibu')";
    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);
}



function input_pendidikan_karyawan($data){
    global $conn;
    $id             = htmlspecialchars($_POST['id']);
    $jenis          = htmlspecialchars($_POST['Jenis']);
    $namasekolah    = htmlspecialchars($_POST['NamaSekolah']);
    $kotasekolah    = htmlspecialchars($_POST['KotaSekolah']);
    $jurusan        = htmlspecialchars($_POST['Jurusan']);
    $tahunlulus     = htmlspecialchars($_POST['ThnLulus']);

    // echo $id,$jenis,$namasekolah,$kotasekolah,$jurusan,$tahunlulus;

    $query          = "INSERT INTO datapendidikan values ('','$id', '$jenis', '$namasekolah', '$kotasekolah', '$jurusan', '$tahunlulus')";

    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);
}

function input_datakeluarga($data){
    global $conn;
    $id             = htmlspecialchars($_POST['id']);
    $hub            = htmlspecialchars($_POST['Hub']);
    $nama           = htmlspecialchars($_POST['Nama']);
    $tgllahir       = htmlspecialchars($_POST['TglLahir']);
    $jeniskelamin   = htmlspecialchars($_POST['JenisKelamin']);
    $pendidikan     = htmlspecialchars($_POST['Pendidikan']);
    $tahunlulus     = htmlspecialchars($_POST['ThnLulus']);
    $query          = "INSERT INTO datakeluarga values ('','$id', '$hub', '$nama', '$tgllahir', '$jeniskelamin', '$pendidikan','$tahunlulus')";

    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);
}

function input_data_sanksi($data){
    global $conn;
    $id       = htmlspecialchars($_POST['id']);
    $jenis    = htmlspecialchars($_POST['Jenis']);
    $masa     = htmlspecialchars($_POST['Masa']);
    $ref      = htmlspecialchars($_POST['Ref']);
    $query    = "INSERT INTO datasanksi values ('', '$id', '$jenis', '$masa', '$ref')";

    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);
}

function input_data_promosidemosimutasi($data){
    global $conn;
    $id             = htmlspecialchars($_POST['id']);
    $tanggal        = htmlspecialchars($_POST['Tanggal']);
    $noref          = htmlspecialchars($_POST['NoRef']);
    $jabatanlama    = htmlspecialchars($_POST['JabatanLama']);
    $jabatanbaru    = htmlspecialchars($_POST['JabatanBaru']);
    $query          = "INSERT INTO datamutasi values ('', '$id', '$tanggal', '$noref', '$jabatanlama', '$jabatanbaru')";

    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);
}

function input_datapengalamankerja($data){
    global $conn;
    $id             = htmlspecialchars($_POST['id']);
    $periodetahun        = htmlspecialchars($_POST['PeriodeThn']);
    $namaperusahaan         = htmlspecialchars($_POST['NamaPerusahaan']);
    $jenisindustri    = htmlspecialchars($_POST['JenisIndustri']);
    $jabatan    = htmlspecialchars($_POST['Jabatan']);
    $query          = "INSERT INTO datapengalaman values ('','$id', '$periodetahun', '$namaperusahaan', '$jenisindustri', '$jabatan')";

    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);
}

function input_data_training($data){
    global $conn;
    $id                     = htmlspecialchars($_POST['id']);
    $periodetgl             = htmlspecialchars($_POST['PeriodeTgl']);
    $instipembertraining    = htmlspecialchars($_POST['InstiPemberTraining']);
    $jenistopik             = htmlspecialchars($_POST['JenisTopik']);
    $score                  = htmlspecialchars($_POST['Score']);
    $query                  = "INSERT INTO datatraining values ('','$id', '$periodetgl', '$instipembertraining', '$jenistopik', '$score')";

    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);
}

function input_data_trainingdipon($data){
    global $conn;
    $id                     = htmlspecialchars($_POST['id']);
    $pertgl             = htmlspecialchars($_POST['PeriodeTgl']);
    $inspembtrai    = htmlspecialchars($_POST['InstiPemberTraining']);
    $jeto            = htmlspecialchars($_POST['JenisTopik']);
    $sco                 = htmlspecialchars($_POST['Score']);
    $query                  = "INSERT INTO datatrainingpon values ('','$id', '$pertgl', '$inspembtrai', '$jeto', '$sco')";

    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);
}


/////////////////////////////////////////////////////////////

//EDIT KARYAWAN
function edit_karyawan($data){
    global $conn;
    $id     = htmlspecialchars($_GET['id']);
    var_dump($id);
    // $nam     = htmlspecialchars($_POST['Nama']); // memanggil nama variabel id untuk dibuat menjadi variabel baru $id
    // $pan     = htmlspecialchars($_POST['Panggilan']);
    // $ini     = htmlspecialchars($_POST['Initial']);
    // $jen     = htmlspecialchars($_POST['JenisKelamin']);
    // $nik     = htmlspecialchars($_POST['NIK']);
    // $nikl     = htmlspecialchars($_POST['NIKLama']);
    // $jam     = htmlspecialchars($_POST['Jamsostek']);
    // $jaml     = htmlspecialchars($_POST['JamsostekLama']);
    // $sta     = htmlspecialchars($_POST['Status']);
    // $tgl     = htmlspecialchars($_POST['TglNikah']);
    // $ban     = htmlspecialchars($_POST['Bank']);
    // $noa     = htmlspecialchars($_POST['NoAcc']);
    // $tglm     = htmlspecialchars($_POST['TglMasuk']);
    // $tgll     = htmlspecialchars($_POST['TglLahir']);
    // $tem     = htmlspecialchars($_POST['TempatLahir']);
    // $aga     = htmlspecialchars($_POST['Agama']);
    // $ala     = htmlspecialchars($_POST['Alamat']);
    // $kot     = htmlspecialchars($_POST['Kota']);
    // $tel     = htmlspecialchars($_POST['Telepon']);
    // $namk     = htmlspecialchars($_POST['NamaKontak']);
    // $alak     = htmlspecialchars($_POST['AlamatKontak']);
    // $kotk     = htmlspecialchars($_POST['KotaKontak']);
    // $telk     = htmlspecialchars($_POST['TelpKontak']);
    // $gold     = htmlspecialchars($_POST['GolDarah']);
    // $dep     = htmlspecialchars($_POST['Departemen']);
    // $div     = htmlspecialchars($_POST['Divisi']);
    // $jab     = htmlspecialchars($_POST['Jabatan']);
    // $rank     = htmlspecialchars($_POST['Rank']);
    // $fot = $_FILES['file']['name'];


    // $file = $_FILES['file']['tmp_name'];
    // $filedest = dirname(__FILE__) . '/images/' . $fot;
    // move_uploaded_file($file, $filedest);
    // // var_dump($nk,$gm,$hk);
    $nama_santri            = htmlspecialchars($_POST['nama_santri']);  
    $jeniskelamin           = htmlspecialchars($_POST['jeniskelamin']);
    $tempatlahir            = htmlspecialchars($_POST['tempatlahir ']);
    $tanggallahir           = htmlspecialchars($_POST['tanggallahir']);
    $no_ktp                 = htmlspecialchars($_POST['no_ktp']);
    $perguruan_tinggi       = htmlspecialchars($_POST['perguruan_tinggi']);
    $no_hp                  = htmlspecialchars($_POST['no_hp']);
    $alamat                 = htmlspecialchars($_POST['alamat']);
    $nama_ayah              = htmlspecialchars($_POST['nama_ayah']);
    $tempat_tgllahir_ayah   = htmlspecialchars($_POST['tempat_tgllahir_ayah']);
    $no_ktp_ayah            = htmlspecialchars($_POST['no_ktp_ayah']);
    $alamat_ayah            = htmlspecialchars($_POST['alamat_ayah']);
    $no_hp_ayah             = htmlspecialchars($_POST['no_hp_ayah']);
    $nama_ibu               = htmlspecialchars($_POST['nama_ibu']);
    $tempat_tgllahir_ibu    = htmlspecialchars($_POST['tempat_tgllahir_ibu']);
    $no_ktp_ibu             = htmlspecialchars($_POST['no_ktp_ibu']);
    $alamat_ibu             = htmlspecialchars($_POST['alamat_ibu']);
    $no_hp_ibu              = htmlspecialchars($_POST['no_hp_ibu']);

    $query="update santri set
    nama_santri='$nama_santri', 
    jeniskelamin='$jeniskelamin', 
    tempatlahir'='$tempatlahir', 
    tanggallahir='$tanggallahir', 
    no_ktp='$no_ktp', 
    perguruan_tinggi='$perguruan_tinggi', 
    no_hp='$no_hp', 
    alamat'$alamat', 
    nama_ayah='$nama_ayah', 
    tempat_tgllahir_ayah='$tempat_tgllahir_ayah', 
    no_ktp_ayah='$no_ktp_ayah', 
    alamat_ayah='$alamat_ayah', 
    no_hp_ayah='$no_hp_ayah', 
    nama_ibu='$nama_ibu', 
    tempat_tgllahir_ibu='$tempat_tgllahir_ibu', 
    no_ktp_ibu='$no_ktp_ibu', 
    alamat_ibu='$alamat_ibu', 
    no_hp_ibu='$no_hp_ibu'
    where id_santri='$id' ";
    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);

    
    if(isset($_POST['simpan'])){

    }else{

    }
}
function edit_pendidikan($data){
    global $conn;
    $id     = htmlspecialchars($_GET['id']);
    // $idk     = htmlspecialchars($_POST['ID_Karyawan']); // memanggil nama variabel id untuk dibuat menjadi variabel baru $id
    // $ni     = htmlspecialchars(md5($_POST['NIK']));
    $je    = htmlspecialchars($_POST['Jenis']);
    $nms    = htmlspecialchars($_POST['NamaSekolah']);
    $kts    = htmlspecialchars($_POST['KotaSekolah']);
    $ju    = htmlspecialchars($_POST['Jurusan']);
    $th    = htmlspecialchars($_POST['ThnLulus']);
    // $jn    = htmlspecialchars($_POST['jenis']);    jenis='$jn'
    // var_dump($ni,$je,$nms,$kts,$ju,$th);
    $query="update datapendidikan set

    
    Jenis='$je',
    NamaSekolah='$nms',
    KotaSekolah='$kts',
    Jurusan='$ju', 
    ThnLulus='$th'

    where ID_Pendidikan='$id' ";
    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);

    
    if(isset($_POST['simpan'])){

    }else{

    }
}

function edit_keluarga($data){
    global $conn;
    $id     = htmlspecialchars($_GET['id']);
    // $idk     = htmlspecialchars($_POST['ID_Karyawan']); // memanggil nama variabel id untuk dibuat menjadi variabel baru $id
    // $ni     = htmlspecialchars(md5($_POST['NIK']));
    $hu    = htmlspecialchars($_POST['Hub']);
    $nm    = htmlspecialchars($_POST['Nama']);
    $tgll    = htmlspecialchars($_POST['TglLahir']);
    $jk    = htmlspecialchars($_POST['JenisKelamin']);
    $pd    = htmlspecialchars($_POST['Pendidikan']);
    $tl    = htmlspecialchars($_POST['ThnLulus']);
    // $jn    = htmlspecialchars($_POST['jenis']);    jenis='$jn'
    // var_dump($ni,$je,$nms,$kts,$ju,$th);
    $query="update datakeluarga set

    
    Hub='$hu',
    Nama='$nm',
    TglLahir='$tgll',
    JenisKelamin='$jk', 
    Pendidikan='$pd',
    ThnLulus='$tl'

    where ID_keluarga='$id' ";
    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);

    
    if(isset($_POST['simpan'])){

    }else{

    }
}
function edit_sanksi($data){
    global $conn;
    $id     = htmlspecialchars($_GET['id']);
    // $idk     = htmlspecialchars($_POST['ID_Karyawan']); // memanggil nama variabel id untuk dibuat menjadi variabel baru $id
    // $ni     = htmlspecialchars(md5($_POST['NIK']));
    $jns    = htmlspecialchars($_POST['Jenis']);
    $mas    = htmlspecialchars($_POST['Masa']);
    $re    = htmlspecialchars($_POST['Ref']);
    // $jn    = htmlspecialchars($_POST['jenis']);    jenis='$jn'
    // var_dump($ni,$je,$nms,$kts,$ju,$th);
    $query="update datasanksi set

    
    Jenis='$jns',
    Masa='$mas',
    Ref='$re'

    where ID_Sanksi='$id' ";
    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);

    
    if(isset($_POST['simpan'])){

    }else{

    }
}
function edit_mutasi($data){
    global $conn;
    $id     = htmlspecialchars($_GET['id']);
    // $idk     = htmlspecialchars($_POST['ID_Karyawan']); // memanggil nama variabel id untuk dibuat menjadi variabel baru $id
    // $ni     = htmlspecialchars(md5($_POST['NIK']));
    $tgl    = htmlspecialchars($_POST['Tanggal']);
    $nr    = htmlspecialchars($_POST['NoRef']);
    $jl    = htmlspecialchars($_POST['JabatanLama']);
    $jb    = htmlspecialchars($_POST['JabatanBaru']);
    // $jn    = htmlspecialchars($_POST['jenis']);    jenis='$jn'
    // var_dump($ni,$je,$nms,$kts,$ju,$th);
    $query="update datamutasi set

    
    Tanggal='$tgl',
    NoRef='$nr',
    JabatanLama='$jl',
    JabatanBaru='$jb'

    where ID_Mutasi='$id' ";
    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);

    
    if(isset($_POST['simpan'])){

    }else{

    }
}

function edit_pengalaman($data){
    global $conn;
    $id     = htmlspecialchars($_GET['id']);
    // $idk     = htmlspecialchars($_POST['ID_Karyawan']); // memanggil nama variabel id untuk dibuat menjadi variabel baru $id
    // $ni     = htmlspecialchars(md5($_POST['NIK']));
    $pt    = htmlspecialchars($_POST['PeriodeThn']);
    $np    = htmlspecialchars($_POST['NamaPerusahaan']);
    $ji    = htmlspecialchars($_POST['JenisIndustri']);
    $jb    = htmlspecialchars($_POST['Jabatan']);
    // $jn    = htmlspecialchars($_POST['jenis']);    jenis='$jn'
    // var_dump($ni,$je,$nms,$kts,$ju,$th);
    $query="update datapengalaman set

    
    PeriodeThn='$pt',
    NamaPerusahaan='$np',
    JenisIndustri='$ji',
    Jabatan='$jb'

    where ID_Pengalaman='$id' ";
    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);

    
    if(isset($_POST['simpan'])){

    }else{

    }
}

function edit_training($data){
    global $conn;
    $id     = htmlspecialchars($_GET['id']);
    // $idk     = htmlspecialchars($_POST['ID_Karyawan']); // memanggil nama variabel id untuk dibuat menjadi variabel baru $id
    // $ni     = htmlspecialchars(md5($_POST['NIK']));
    $pt    = htmlspecialchars($_POST['PeriodeTgl']);
    $ipt    = htmlspecialchars($_POST['InstiPemberTraining']);
    $jt    = htmlspecialchars($_POST['JenisTopik']);
    $sc    = htmlspecialchars($_POST['Score']);
    // $jn    = htmlspecialchars($_POST['jenis']);    jenis='$jn'
    // var_dump($ni,$je,$nms,$kts,$ju,$th);
    $query="update datatraining set

    
    PeriodeTgl='$pt',
    InstiPemberTraining='$ipt',
    JenisTopik='$jt',
    Score='$sc'

    where ID_Training='$id' ";
    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);

    
    if(isset($_POST['simpan'])){

    }else{

    }
}
function edit_trainingpon($data){
    global $conn;
    $id     = htmlspecialchars($_GET['id']);
    // $idk     = htmlspecialchars($_POST['ID_Karyawan']); // memanggil nama variabel id untuk dibuat menjadi variabel baru $id
    // $ni     = htmlspecialchars(md5($_POST['NIK']));
    $pt    = htmlspecialchars($_POST['PeriodeTgl']);
    $ipt    = htmlspecialchars($_POST['InstiPemberTraining']);
    $jt    = htmlspecialchars($_POST['JenisTopik']);
    $sc    = htmlspecialchars($_POST['Score']);
    // $jn    = htmlspecialchars($_POST['jenis']);    jenis='$jn'
    // var_dump($ni,$je,$nms,$kts,$ju,$th);
    $query="update datatrainingpon set

    
    PeriodeTgl='$pt',
    InstiPemberTraining='$ipt',
    JenisTopik='$jt',
    Score='$sc'

    where ID_TrainingPON='$id' ";
    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);

    
    if(isset($_POST['simpan'])){

    }else{

    }
}

function hapus_trainingpon($id){
    global $conn;
    mysqli_query($conn,"DELETE FROM datatrainingpon WHERE ID_TrainingPON=$id");
    return mysqli_affected_rows($conn);
}
function hapus_training($id){
    global $conn;
    mysqli_query($conn,"DELETE FROM datatraining WHERE ID_Training=$id");
    return mysqli_affected_rows($conn);
}
function hapus_pengalaman($id){
    global $conn;
    mysqli_query($conn,"DELETE FROM datapengalaman WHERE ID_Pengalaman=$id");
    return mysqli_affected_rows($conn);
}
function hapus_mutasi($id){
    global $conn;
    mysqli_query($conn,"DELETE FROM datamutasi WHERE ID_Mutasi=$id");
    return mysqli_affected_rows($conn);
}
function hapus_sanksi($id){
    global $conn;
    mysqli_query($conn,"DELETE FROM datasanksi WHERE ID_Sanksi=$id");
    return mysqli_affected_rows($conn);
}
function hapus_keluarga($id){
    global $conn;
    mysqli_query($conn,"DELETE FROM datakeluarga WHERE ID_keluarga=$id");
    return mysqli_affected_rows($conn);
}
function hapus_pendidikan($id){
    global $conn;
    mysqli_query($conn,"DELETE FROM datapendidikan WHERE ID_Pendidikan=$id");
    return mysqli_affected_rows($conn);
}
function hapus_karyawan($id)
{
    global $conn;

    // Hapus pendidikan
    mysqli_query($conn, "DELETE FROM datapendidikan WHERE ID_Karyawan = '$id'");
    // hapus training PON
    mysqli_query($conn, "DELETE FROM datatrainingpon WHERE ID_Karyawan = '$id'");
    // hapus data pengalaman
    mysqli_query($conn, "DELETE FROM datapengalaman WHERE ID_Karyawan = '$id'");
    // data keluarga
    mysqli_query($conn, "DELETE FROM datakeluarga WHERE ID_Karyawan = '$id'");
    // data mutasi
    mysqli_query($conn, "DELETE FROM datamutasi WHERE ID_Karyawan = '$id'");
    // data training
    mysqli_query($conn, "DELETE FROM datatraining WHERE ID_Karyawan = '$id'");
    // data sanksi
    mysqli_query($conn, "DELETE FROM datasanksi WHERE ID_Karyawan = '$id'");

    // hapus pengguna
    mysqli_query($conn, "DELETE FROM datakaryawan WHERE ID_Karyawan = '$id'");    

    // print_r ($data);
    return mysqli_affected_rows($conn);
}


function upload(){
    $nama_file = $_FILES['photo']['name'];
    $ukuran_file = $_FILES['photo']['size'];
    $error = $_FILES['photo']['error'];
    $file_tmp = $_FILES['photo']['tmp_name'];

    if ($error === 4) {
        echo "
        <script>
        alert('Tidak ada gambar yang diupload');
        </script>
        ";
        return false;
    }

    $jenis_gambar = ['jpg', 'jpeg', 'png', 'gif']; //jenis gambar yang boleh diinputkan
    $pecah_gambar = explode(".", $nama_file); //Memecah nama file dengan jenis gambar
    $pecah_gambar = strtolower(end($pecah_gambar)); //mengambil data array paling belakang
    if (!in_array($pecah_gambar, $jenis_gambar)) {
        echo "
        <script>
        alert('Yang anda upload bukan file gambar');
        </script>
        ";
        return false;
    }
    //cek kapasitas file yang diupload dala bentuk byte 1 MB = 1000000 Byte
    if ($ukuran_file > 10000000) {
        echo"
        <script>
        alert('Ukuran file terlalu besar');
        </script>
        ";
        return false;
    }

    $namafilebaru = uniqid();
    $namafilebaru .= ".";
    $namafilebaru .= $pecah_gambar;

    move_uploaded_file($file_tmp, 'img/'.$namafilebaru);

    //mereturn nama file agar masuk ke $gambar == upload()
    return $namafilebaru;
}

function input_keluarga($data){
    global $conn;
    $nk    = htmlspecialchars($_POST['nama_kue']);
    $hk    = htmlspecialchars($_POST['harga_kue']);

    $query = "INSERT INTO tb_dagang values ('','$nk','$gm','$hk')";
    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);

}

?>